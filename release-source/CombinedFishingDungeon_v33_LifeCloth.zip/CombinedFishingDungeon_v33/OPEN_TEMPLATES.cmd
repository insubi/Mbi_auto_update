@echo off
setlocal
start "" explorer "%~dp0FishingAutomation\templates"
