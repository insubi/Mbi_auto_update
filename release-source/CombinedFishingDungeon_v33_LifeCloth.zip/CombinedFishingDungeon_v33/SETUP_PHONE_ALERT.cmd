@echo off
setlocal
cd /d "%~dp0"
title Mabinogi Phone Alert Setup
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\SetupPhoneAlert.ps1"
echo.
echo Setup finished. Press any key to close this window.
pause >nul
