@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if exist "%~dp0release" rmdir /s /q "%~dp0release"
call "%~dp0BUILD.cmd"
if errorlevel 1 exit /b 1
call "%~dp0START.cmd"
