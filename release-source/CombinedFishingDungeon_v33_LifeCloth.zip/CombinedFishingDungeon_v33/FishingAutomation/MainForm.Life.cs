using DungeonVisionBot;

namespace FishingAutomation;

public sealed partial class MainForm
{
    private LifeSettings _lifeSettings = new();
    private string _lifeSettingsPath = "";
    private CancellationTokenSource? _lifeCts;
    private Task? _lifeTask;
    private DateTime? _lifeStartedAt;
    private DateTime? _lifeStoppedAt;
    private int _lifeProcessingBatches;
    private int _lifeGatherCycles;
    private int _lifeWoolCurrent;

    private readonly NumericUpDown _lifeWoolTarget = new();
    private readonly Label _lifeStageValue = new();
    private readonly Label _lifeWoolValue = new();
    private Control _lifePicker = null!;

    private bool LifeRunning => _lifeTask is { IsCompleted: false };

    private void InitializeLifeSettings(string baseDir)
    {
        _lifeSettingsPath = Path.Combine(baseDir, "life", "settings.json");
        _lifeSettings = LifeSettings.Load(_lifeSettingsPath);
    }

    private Control BuildLifeSettingsPanel()
    {
        var panel = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 3,
            Margin = Padding.Empty,
            Padding = new Padding(0, 2, 0, 2)
        };
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
        panel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        var feature = SmallButton("옷감 가공", () => { });
        feature.Dock = DockStyle.Fill;
        feature.BackColor = AccentSoft;
        feature.Enabled = false;
        panel.Controls.Add(feature, 0, 0);

        var targetRow = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1 };
        targetRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 58));
        targetRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 42));
        targetRow.Controls.Add(new Label
        {
            Text = "양털 목표 수량",
            Dock = DockStyle.Fill,
            ForeColor = TitleText,
            TextAlign = ContentAlignment.MiddleLeft,
            Font = new Font("맑은 고딕", 9f, FontStyle.Bold)
        }, 0, 0);

        _lifeWoolTarget.Minimum = 1;
        _lifeWoolTarget.Maximum = 9999;
        _lifeWoolTarget.Value = Math.Clamp(_lifeSettings.WoolTarget, 1, 9999);
        _lifeWoolTarget.Dock = DockStyle.Fill;
        _lifeWoolTarget.BackColor = CardBg2;
        _lifeWoolTarget.ForeColor = TitleText;
        _lifeWoolTarget.BorderStyle = BorderStyle.FixedSingle;
        _lifeWoolTarget.TextAlign = HorizontalAlignment.Right;
        _lifeWoolTarget.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
        _lifeWoolTarget.ValueChanged += (_, _) =>
        {
            if (LifeRunning || _activeMode == "생활") return;
            _lifeSettings.WoolTarget = (int)_lifeWoolTarget.Value;
            try { _lifeSettings.Save(_lifeSettingsPath); } catch { }
            _lifeWoolValue.Text = $"목표 {_lifeSettings.WoolTarget}개";
        };
        targetRow.Controls.Add(_lifeWoolTarget, 1, 0);
        panel.Controls.Add(targetRow, 0, 1);

        var state = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2 };
        state.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
        state.RowStyles.Add(new RowStyle(SizeType.Percent, 50));

        _lifeStageValue.Text = "대기";
        _lifeStageValue.Dock = DockStyle.Fill;
        _lifeStageValue.ForeColor = Muted;
        _lifeStageValue.TextAlign = ContentAlignment.MiddleLeft;
        _lifeStageValue.Font = new Font("맑은 고딕", 8.5f, FontStyle.Bold);
        _lifeStageValue.AutoEllipsis = true;

        _lifeWoolValue.Text = $"목표 {_lifeSettings.WoolTarget}개";
        _lifeWoolValue.Dock = DockStyle.Fill;
        _lifeWoolValue.ForeColor = Color.FromArgb(113, 191, 255);
        _lifeWoolValue.TextAlign = ContentAlignment.MiddleLeft;
        _lifeWoolValue.Font = new Font("맑은 고딕", 8.5f, FontStyle.Bold);
        _lifeWoolValue.AutoEllipsis = true;

        state.Controls.Add(_lifeStageValue, 0, 0);
        state.Controls.Add(_lifeWoolValue, 0, 1);
        panel.Controls.Add(state, 0, 2);
        return panel;
    }

    private async Task StartLifeAsync()
    {
        _starting = true;
        _cancelStart = false;
        try
        {
            var window = WindowTools.EnumerateVisibleWindows().FirstOrDefault();
            if (window is null)
            {
                SetStatus("게임 창 없음", Color.Firebrick);
                _log.Write("[생활] 마비노기 모바일 창을 찾지 못했습니다.");
                return;
            }

            string baseDir = AppContext.BaseDirectory;
            var app = LoadJson<AppSettings>(Path.Combine(baseDir, "dungeon", "config", "appsettings.json"));
            _lifeSettings.WoolTarget = (int)_lifeWoolTarget.Value;
            _lifeSettings.Save(_lifeSettingsPath);

            if (app.ForceClientSizeAndTopRight)
            {
                WindowTools.EnsureClientSizeAndTopRight(window.Handle, app.ClientWidth, app.ClientHeight);
                await Task.Delay(500);
            }

            if (_cancelStart || IsDisposed) return;

            var engine = new LifeAutomationEngine(window.Handle, app, _lifeSettings, baseDir, _lifeSettingsPath);
            _activeMode = "생활";
            _mode.Enabled = false;
            _abyssDungeon.Enabled = false;
            _lifeWoolTarget.Enabled = false;
            _lifeStartedAt = DateTime.Now;
            _lifeStoppedAt = null;
            _lifeProcessingBatches = 0;
            _lifeGatherCycles = 0;
            _lifeWoolCurrent = 0;
            _lifeStageValue.Text = "시작 준비";
            _lifeWoolValue.Text = $"0 / {_lifeSettings.WoolTarget}개";
            _lifeCts = new CancellationTokenSource();
            _inputValue.Text = engine.InputMode;
            SetStatus("생활 · 옷감 가공 실행 중", Blue);
            _log.Write($"[생활] 옷감 가공 시작(F9) · 목표 양털={_lifeSettings.WoolTarget} · 입력={engine.InputMode}");

            engine.Log += text => Ui(() => _log.Write("[생활] " + text));
            engine.StageChanged += stage => Ui(() =>
            {
                _lifeStageValue.Text = stage;
                SetStatus("생활 · " + stage, Blue);
                UpdateStats();
            });
            engine.WoolCountChanged += count => Ui(() =>
            {
                _lifeWoolCurrent = count;
                _lifeWoolValue.Text = $"{count} / {_lifeSettings.WoolTarget}개";
                UpdateStats();
            });
            engine.CountersChanged += (batches, gathers) => Ui(() =>
            {
                _lifeProcessingBatches = batches;
                _lifeGatherCycles = gathers;
                UpdateStats();
            });

            _lifeTask = Task.Run(async () =>
            {
                using (engine)
                {
                    try
                    {
                        await engine.RunAsync(_lifeCts.Token);
                    }
                    catch (OperationCanceledException)
                    {
                        Ui(() => _log.Write("[생활] 정지되었습니다."));
                    }
                    catch (Exception ex)
                    {
                        Ui(() =>
                        {
                            _log.Write("[생활] 오류: " + ex.Message);
                            SetStatus("생활 오류", Color.Salmon);
                            _ = _notifier.SendAlertAsync("생활 자동화 오류", ex.Message, true);
                        });
                    }
                    finally
                    {
                        Ui(() =>
                        {
                            _lifeStoppedAt = DateTime.Now;
                            _activeMode = null;
                            _mode.Enabled = true;
                            _lifeWoolTarget.Enabled = true;
                            UpdateAbyssSelectorVisibility();
                            if (_statusValue.Text != "생활 오류") RefreshModeStatus();
                            UpdateStats();
                        });
                    }
                }
            });
        }
        catch (Exception ex)
        {
            _activeMode = null;
            _mode.Enabled = true;
            _lifeWoolTarget.Enabled = true;
            SetStatus("생활 시작 실패", Color.Salmon);
            _log.Write("[생활] 시작 실패: " + ex.Message);
            _ = _notifier.SendAlertAsync("생활 시작 실패", ex.Message, true);
        }
        finally
        {
            _starting = false;
            UpdateStats();
        }
    }

    private void StopLife()
    {
        if (LifeRunning && _lifeCts is not null && !_lifeCts.IsCancellationRequested)
        {
            _log.Write("[생활] 정지 요청(F10)");
            _lifeCts.Cancel();
        }
    }
}
