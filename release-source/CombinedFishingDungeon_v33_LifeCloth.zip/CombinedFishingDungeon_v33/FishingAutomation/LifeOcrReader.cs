using System.Drawing.Imaging;
using System.Text.RegularExpressions;
using Windows.Globalization;
using Windows.Graphics.Imaging;
using Windows.Media.Ocr;
using Windows.Storage.Streams;

namespace FishingAutomation;

internal sealed record LifeOcrLine(string Text, Rectangle Bounds);

internal sealed class LifeOcrReader
{
    private readonly OcrEngine _engine;

    public LifeOcrReader()
    {
        _engine = OcrEngine.TryCreateFromLanguage(new Language("ko-KR"))
            ?? OcrEngine.TryCreateFromUserProfileLanguages()
            ?? throw new InvalidOperationException("Windows 한국어 OCR 엔진을 만들 수 없습니다.");
    }

    public async Task<List<LifeOcrLine>> ReadLinesAsync(Bitmap frame, Rectangle roi, int scale, CancellationToken ct)
    {
        ct.ThrowIfCancellationRequested();
        Rectangle safe = Rectangle.Intersect(new Rectangle(Point.Empty, frame.Size), roi);
        if (safe.Width <= 0 || safe.Height <= 0) return new();

        using var crop = frame.Clone(safe, PixelFormat.Format24bppRgb);
        using var prepared = scale <= 1
            ? (Bitmap)crop.Clone()
            : ResizeNearest(crop, crop.Width * scale, crop.Height * scale);
        using var software = await ToSoftwareBitmapAsync(prepared);
        var result = await _engine.RecognizeAsync(software);
        ct.ThrowIfCancellationRequested();

        var lines = new List<LifeOcrLine>();
        foreach (var line in result.Lines)
        {
            if (line.Words.Count == 0) continue;
            string text = string.Join(" ", line.Words.Select(w => w.Text)).Trim();
            if (text.Length == 0) continue;

            double left = line.Words.Min(w => w.BoundingRect.X);
            double top = line.Words.Min(w => w.BoundingRect.Y);
            double right = line.Words.Max(w => w.BoundingRect.X + w.BoundingRect.Width);
            double bottom = line.Words.Max(w => w.BoundingRect.Y + w.BoundingRect.Height);

            lines.Add(new LifeOcrLine(text, Rectangle.FromLTRB(
                safe.X + (int)Math.Round(left / scale),
                safe.Y + (int)Math.Round(top / scale),
                safe.X + (int)Math.Round(right / scale),
                safe.Y + (int)Math.Round(bottom / scale))));
        }
        return lines;
    }

    public async Task<LifeOcrLine?> FindExactAsync(Bitmap frame, Rectangle roi, string exact, CancellationToken ct)
    {
        string wanted = NormalizeLoose(exact);
        foreach (int scale in new[] { 1, 2 })
        {
            var lines = await ReadLinesAsync(frame, roi, scale, ct);
            var hit = lines.FirstOrDefault(line => NormalizeLoose(line.Text) == wanted);
            if (hit is not null) return hit;
        }
        return null;
    }

    public async Task<bool> ContainsAsync(Bitmap frame, Rectangle roi, string wanted, CancellationToken ct)
    {
        string normalized = NormalizeLoose(wanted);
        foreach (int scale in new[] { 1, 2 })
        {
            var lines = await ReadLinesAsync(frame, roi, scale, ct);
            if (lines.Any(line => NormalizeLoose(line.Text).Contains(normalized, StringComparison.Ordinal)))
                return true;
        }
        return false;
    }

    public async Task<int> CountExactAsync(Bitmap frame, Rectangle roi, string exact, CancellationToken ct)
    {
        string wanted = NormalizeLoose(exact);
        int best = 0;
        foreach (int scale in new[] { 1, 2 })
        {
            var lines = await ReadLinesAsync(frame, roi, scale, ct);
            int count = lines.Count(line => NormalizeLoose(line.Text) == wanted);
            best = Math.Max(best, count);
        }
        return best;
    }

    public async Task<List<int>> ReadIntegersAsync(Bitmap frame, Rectangle roi, CancellationToken ct)
    {
        var values = new List<int>();
        foreach (int scale in new[] { 2, 1 })
        {
            var lines = await ReadLinesAsync(frame, roi, scale, ct);
            foreach (var line in lines)
            {
                foreach (Match match in Regex.Matches(line.Text.Replace(",", ""), @"\d{1,4}"))
                {
                    if (int.TryParse(match.Value, out int n) && n is >= 0 and <= 9999)
                        values.Add(n);
                }
            }
            if (values.Count > 0) break;
        }
        return values;
    }

    public static string NormalizeLoose(string text) => new(text.Where(char.IsLetterOrDigit).ToArray());

    private static Bitmap ResizeNearest(Bitmap src, int w, int h)
    {
        var dst = new Bitmap(w, h, PixelFormat.Format24bppRgb);
        using var g = Graphics.FromImage(dst);
        g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.NearestNeighbor;
        g.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.Half;
        g.DrawImage(src, new Rectangle(0, 0, w, h));
        return dst;
    }

    private static async Task<SoftwareBitmap> ToSoftwareBitmapAsync(Bitmap bitmap)
    {
        using var png = new MemoryStream();
        bitmap.Save(png, ImageFormat.Png);
        byte[] bytes = png.ToArray();

        using var stream = new InMemoryRandomAccessStream();
        using (var writer = new DataWriter(stream))
        {
            writer.WriteBytes(bytes);
            await writer.StoreAsync();
            await writer.FlushAsync();
            writer.DetachStream();
        }

        stream.Seek(0);
        var decoder = await BitmapDecoder.CreateAsync(stream);
        return await decoder.GetSoftwareBitmapAsync(BitmapPixelFormat.Bgra8, BitmapAlphaMode.Premultiplied);
    }
}
