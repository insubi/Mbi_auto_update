using System.Text.Json;

namespace FishingAutomation;

public sealed class LifeSettings
{
    public int WoolTarget { get; set; } = 1000;
    public int WoolCheckIntervalSeconds { get; set; } = 20;
    public int TemplatePollMs { get; set; } = 300;
    public int ClickSettleMs { get; set; } = 500;
    public int? CharacterButtonX { get; set; }
    public int? CharacterButtonY { get; set; }

    public static LifeSettings Load(string path)
    {
        try
        {
            if (File.Exists(path))
            {
                var value = JsonSerializer.Deserialize<LifeSettings>(
                    File.ReadAllText(path),
                    new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

                if (value is not null)
                {
                    value.Normalize();
                    return value;
                }
            }
        }
        catch
        {
            // Invalid settings must never prevent the main program from starting.
        }

        return new LifeSettings();
    }

    public void Save(string path)
    {
        Normalize();
        string? dir = Path.GetDirectoryName(path);
        if (!string.IsNullOrWhiteSpace(dir)) Directory.CreateDirectory(dir);
        File.WriteAllText(path, JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true }));
    }

    public LifeSettings Clone() => new()
    {
        WoolTarget = WoolTarget,
        WoolCheckIntervalSeconds = WoolCheckIntervalSeconds,
        TemplatePollMs = TemplatePollMs,
        ClickSettleMs = ClickSettleMs,
        CharacterButtonX = CharacterButtonX,
        CharacterButtonY = CharacterButtonY
    };

    private void Normalize()
    {
        WoolTarget = Math.Clamp(WoolTarget, 1, 9999);
        WoolCheckIntervalSeconds = Math.Clamp(WoolCheckIntervalSeconds, 5, 300);
        TemplatePollMs = Math.Clamp(TemplatePollMs, 100, 2000);
        ClickSettleMs = Math.Clamp(ClickSettleMs, 150, 3000);

        if (CharacterButtonX is < 0 or > 799) CharacterButtonX = null;
        if (CharacterButtonY is < 0 or > 999) CharacterButtonY = null;
        if (CharacterButtonX is null || CharacterButtonY is null)
        {
            CharacterButtonX = null;
            CharacterButtonY = null;
        }
    }
}
