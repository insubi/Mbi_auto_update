﻿using OpenCvSharp;
using OpenCvSharp.Extensions;

namespace FishingAutomation;

internal sealed class LifeTemplateMatcher : IDisposable
{
    private readonly string _templateDir;
    private readonly Dictionary<string, Mat> _cache = new(StringComparer.OrdinalIgnoreCase);

    public LifeTemplateMatcher(string templateDir) => _templateDir = templateDir;

    public MatchResult Find(
        Bitmap frame,
        Rectangle roi,
        string fileName,
        double threshold = 0.62,
        double minScale = 0.40,
        double maxScale = 1.60,
        double step = 0.08)
    {
        Rectangle safe = Rectangle.Intersect(new Rectangle(System.Drawing.Point.Empty, frame.Size), roi);
        if (safe.Width < 12 || safe.Height < 12)
            return new MatchResult { Score = 0, Rect = Rectangle.Empty };

        using var crop = frame.Clone(safe, System.Drawing.Imaging.PixelFormat.Format24bppRgb);
        using var srcBgr = BitmapConverter.ToMat(crop);
        using var src = new Mat();
        Cv2.CvtColor(srcBgr, src, ColorConversionCodes.BGR2GRAY);

        Mat tplOriginal = GetTemplate(fileName);
        double bestScore = double.NegativeInfinity;
        OpenCvSharp.Point bestLoc = default;
        int bestW = 0, bestH = 0;
        double bestScale = 1.0;

        foreach (double scale in EnumerateScales(minScale, maxScale, step))
        {
            int w = Math.Max(8, (int)Math.Round(tplOriginal.Width * scale));
            int h = Math.Max(8, (int)Math.Round(tplOriginal.Height * scale));
            if (w > src.Width || h > src.Height) continue;

            using var tpl = Resize(tplOriginal, w, h, scale);
            using var result = new Mat();
            Cv2.MatchTemplate(src, tpl, result, TemplateMatchModes.CCoeffNormed);
            Cv2.MinMaxLoc(result, out _, out double max, out _, out OpenCvSharp.Point p);
            if (max > bestScore)
            {
                bestScore = max;
                bestLoc = p;
                bestW = w;
                bestH = h;
                bestScale = scale;
            }
        }

        if (double.IsNegativeInfinity(bestScore) || bestScore < threshold || bestW <= 0 || bestH <= 0)
            return new MatchResult { Score = Math.Max(0, bestScore), Rect = Rectangle.Empty, Scale = bestScale };

        return new MatchResult
        {
            Score = bestScore,
            Scale = bestScale,
            Rect = new Rectangle(safe.X + bestLoc.X, safe.Y + bestLoc.Y, bestW, bestH)
        };
    }

    public List<MatchResult> FindAll(
        Bitmap frame,
        Rectangle roi,
        string fileName,
        double threshold = 0.68,
        double minScale = 0.50,
        double maxScale = 1.45,
        double step = 0.10,
        int maxMatches = 12)
    {
        Rectangle safe = Rectangle.Intersect(new Rectangle(System.Drawing.Point.Empty, frame.Size), roi);
        if (safe.Width < 12 || safe.Height < 12 || maxMatches <= 0) return new();

        using var crop = frame.Clone(safe, System.Drawing.Imaging.PixelFormat.Format24bppRgb);
        using var srcBgr = BitmapConverter.ToMat(crop);
        using var src = new Mat();
        Cv2.CvtColor(srcBgr, src, ColorConversionCodes.BGR2GRAY);

        Mat original = GetTemplate(fileName);
        var candidates = new List<MatchResult>();

        foreach (double scale in EnumerateScales(minScale, maxScale, step))
        {
            int w = Math.Max(8, (int)Math.Round(original.Width * scale));
            int h = Math.Max(8, (int)Math.Round(original.Height * scale));
            if (w > src.Width || h > src.Height) continue;

            using var tpl = Resize(original, w, h, scale);
            using var result = new Mat();
            Cv2.MatchTemplate(src, tpl, result, TemplateMatchModes.CCoeffNormed);

            int localLimit = Math.Max(maxMatches * 2, 14);
            for (int i = 0; i < localLimit; i++)
            {
                Cv2.MinMaxLoc(result, out _, out double max, out _, out OpenCvSharp.Point p);
                if (max < threshold) break;

                var rect = new Rectangle(safe.X + p.X, safe.Y + p.Y, w, h);
                candidates.Add(new MatchResult { Score = max, Rect = rect, Scale = scale });

                int sx = Math.Max(0, p.X - w / 3);
                int sy = Math.Max(0, p.Y - h / 3);
                int sw = Math.Min(result.Width - sx, Math.Max(1, w * 2 / 3));
                int sh = Math.Min(result.Height - sy, Math.Max(1, h * 2 / 3));
                if (sw > 0 && sh > 0)
                    Cv2.Rectangle(result, new OpenCvSharp.Rect(sx, sy, sw, sh), Scalar.All(-1), -1);
            }
        }

        var selected = new List<MatchResult>();
        foreach (var candidate in candidates.OrderByDescending(x => x.Score))
        {
            if (selected.Any(x => IoU(x.Rect, candidate.Rect) >= 0.35)) continue;
            selected.Add(candidate);
            if (selected.Count >= maxMatches) break;
        }

        return selected;
    }

    private Mat GetTemplate(string fileName)
    {
        if (_cache.TryGetValue(fileName, out var cached)) return cached;

        string path = Path.Combine(_templateDir, fileName);
        if (!File.Exists(path)) throw new FileNotFoundException("생활 템플릿이 없습니다.", path);

        using var bgr = Cv2.ImRead(path, ImreadModes.Color);
        if (bgr.Empty()) throw new InvalidDataException("생활 템플릿 읽기 실패: " + path);

        var gray = new Mat();
        Cv2.CvtColor(bgr, gray, ColorConversionCodes.BGR2GRAY);
        _cache[fileName] = gray;
        return gray;
    }

    private static IEnumerable<double> EnumerateScales(double min, double max, double step)
    {
        min = Math.Clamp(min, 0.20, 3.0);
        max = Math.Clamp(max, min, 3.0);
        step = Math.Clamp(step, 0.02, 0.50);
        for (double scale = min; scale <= max + 0.0001; scale += step)
            yield return scale;
    }

    private static Mat Resize(Mat original, int w, int h, double scale)
    {
        var tpl = new Mat();
        if (w == original.Width && h == original.Height)
            original.CopyTo(tpl);
        else
            Cv2.Resize(original, tpl, new OpenCvSharp.Size(w, h), 0, 0,
                scale < 1.0 ? InterpolationFlags.Area : InterpolationFlags.Cubic);
        return tpl;
    }

    private static double IoU(Rectangle a, Rectangle b)
    {
        Rectangle i = Rectangle.Intersect(a, b);
        if (i.Width <= 0 || i.Height <= 0) return 0;
        double ia = i.Width * (double)i.Height;
        double ua = a.Width * (double)a.Height + b.Width * (double)b.Height - ia;
        return ua <= 0 ? 0 : ia / ua;
    }

    public void Dispose()
    {
        foreach (var mat in _cache.Values) mat.Dispose();
        _cache.Clear();
    }
}
