﻿using System.Text.RegularExpressions;
using DungeonVisionBot;
using OpenCvSharp;
using OpenCvSharp.Extensions;

namespace FishingAutomation;

internal sealed class LifeAutomationEngine : IDisposable
{
    private readonly nint _hwnd;
    private readonly AppSettings _app;
    private readonly LifeSettings _settings;
    private readonly string _settingsPath;
    private readonly string _debugDir;
    private readonly WindowCapture _capture = new();
    private readonly LifeTemplateMatcher _matcher;
    private readonly LifeOcrReader _ocr;
    private readonly DungeonVisionBot.IInputController _input;
    private DateTime _lastShortageOcrAt = DateTime.MinValue;
    private bool _lastShortageOcrValue;
    private int _processingBatches;
    private int _gatherCycles;

    public event Action<string>? Log;
    public event Action<string>? StageChanged;
    public event Action<int>? WoolCountChanged;
    public event Action<int, int>? CountersChanged;

    public string InputMode => _input.ModeName;

    public LifeAutomationEngine(
        nint hwnd,
        AppSettings app,
        LifeSettings settings,
        string baseDir,
        string settingsPath)
    {
        _hwnd = hwnd;
        _app = app;
        _settings = settings;
        _settingsPath = settingsPath;
        _debugDir = Path.Combine(baseDir, "debug", "life");
        _matcher = new LifeTemplateMatcher(Path.Combine(baseDir, "life", "templates"));
        _ocr = new LifeOcrReader();

        if (!_app.UseInterception)
            throw new InvalidOperationException("생활 자동화는 Interception 마우스/키보드 입력을 사용합니다.");

        _input = new DungeonVisionBot.InterceptionInput(_app.InterceptionMouseDevice, _app.InterceptionKeyboardDevice);
    }

    public async Task RunAsync(CancellationToken ct)
    {
        NativeMethods.SetForegroundWindow(_hwnd);
        if (_app.ForceClientSizeAndTopRight)
        {
            WindowTools.EnsureClientSizeAndTopRight(_hwnd, _app.ClientWidth, _app.ClientHeight);
            await Task.Delay(500, ct);
        }

        Emit($"시작 · 양털 목표={_settings.WoolTarget}개 · 수량 확인 간격={_settings.WoolCheckIntervalSeconds}초");
        Stage("가공 준비");

        // Starting from an arbitrary menu is safer if we first return to the field HUD.
        await CloseAllPanelsAsync(ct, allowNoX: true);

        while (true)
        {
            ct.ThrowIfCancellationRequested();
            await RunProcessingUntilShortageWithRecoveryAsync(ct);
            ct.ThrowIfCancellationRequested();
            await RunGatheringUntilTargetWithRecoveryAsync(ct);
        }
    }

    private async Task RunProcessingUntilShortageWithRecoveryAsync(CancellationToken ct)
    {
        int attempt = 0;
        while (true)
        {
            try
            {
                await RunProcessingUntilShortageAsync(ct);
                return;
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                attempt++;
                SaveDebug("processing_error");
                Emit($"[자동복구] 가공 오류 {attempt}/{Math.Max(1, _app.AutoRecoveryMaxAttempts)} · {ex.Message}");
                if (!_app.AutoRecoveryEnabled || attempt >= Math.Max(1, _app.AutoRecoveryMaxAttempts)) throw;
                await CloseAllPanelsAsync(ct, allowNoX: true);
                await Task.Delay(Math.Max(1, _app.AutoRecoveryDelaySeconds) * 1000, ct);
            }
        }
    }

    private async Task RunGatheringUntilTargetWithRecoveryAsync(CancellationToken ct)
    {
        int attempt = 0;
        while (true)
        {
            try
            {
                await RunGatheringUntilTargetAsync(ct);
                return;
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                attempt++;
                SaveDebug("gather_error");
                Emit($"[자동복구] 채집 오류 {attempt}/{Math.Max(1, _app.AutoRecoveryMaxAttempts)} · {ex.Message}");
                if (!_app.AutoRecoveryEnabled || attempt >= Math.Max(1, _app.AutoRecoveryMaxAttempts)) throw;
                await CloseAllPanelsAsync(ct, allowNoX: true);
                await Task.Delay(Math.Max(1, _app.AutoRecoveryDelaySeconds) * 1000, ct);
            }
        }
    }

    private async Task RunProcessingUntilShortageAsync(CancellationToken ct)
    {
        Stage("가공장 이동");
        await OpenProcessingFacilityAsync(ct);

        while (true)
        {
            ct.ThrowIfCancellationRequested();
            using var frame = _capture.CaptureClient(_hwnd);

            if (await IsMaterialShortageAsync(frame, ct))
            {
                Emit("재료가 부족합니다 감지 → 가공창 닫기");
                Stage("재료 부족 · 채집 전환");
                await Task.Delay(500, ct);
                await CloseAllPanelsAsync(ct, allowNoX: false);
                return;
            }

            if (await IsQueueCompletedAsync(frame, ct))
            {
                Stage("가공 완료 · 모두 받기");
                await ReceiveAllAsync(ct);
                _processingBatches++;
                CountersChanged?.Invoke(_processingBatches, _gatherCycles);
                await Task.Delay(600, ct);
                continue;
            }

            if (IsQueueFull(frame))
            {
                Stage("7번 슬롯 100% 대기");
                await Task.Delay(900, ct);
                continue;
            }

            Stage("가공 대기열 채우기");
            await QueueOneClothAsync(ct);
            await Task.Delay(350, ct);
        }
    }

    private async Task OpenProcessingFacilityAsync(CancellationToken ct)
    {
        await ClickTemplateAsync("processing_tab.jpg", "가공 탭", 20, ct, threshold: 0.55);

        using (var frame = _capture.CaptureClient(_hwnd))
        {
            if (!Found(frame, "processing_menu_on.jpg", 0.55))
            {
                // The inactive version is intentionally preferred so the click is only sent when needed.
                await ClickTemplateAsync("processing_menu_off.jpg", "가공 메뉴", 12, ct, threshold: 0.50);
                await WaitTemplateAsync("processing_menu_on.jpg", "가공 메뉴 활성화", 8, ct, threshold: 0.50);
            }
            else
            {
                Emit("가공 메뉴가 이미 활성 상태입니다.");
            }
        }

        await ClickTemplateAsync("cloth_processing.jpg", "옷감 가공", 15, ct, threshold: 0.52);
        await ClickTemplateOrTextAsync("go_facility.jpg", "설비로 이동", "설비로 이동", 15, ct, 0.55);

        Stage("설비 이동 중");
        await WaitForProcessingScreenAsync(ct);
    }

    private async Task WaitForProcessingScreenAsync(CancellationToken ct)
    {
        DateTime deadline = DateTime.UtcNow.AddSeconds(60);
        while (DateTime.UtcNow < deadline)
        {
            ct.ThrowIfCancellationRequested();
            using var frame = _capture.CaptureClient(_hwnd);
            if (Found(frame, "receive_all_off.jpg", 0.50) ||
                Found(frame, "receive_all_on.jpg", 0.50) ||
                Found(frame, "process_go.jpg", 0.50) ||
                Found(frame, "cloth_item_label.jpg", 0.48))
            {
                Emit("옷감 가공 설비 화면 확인");
                return;
            }
            await Task.Delay(_settings.TemplatePollMs, ct);
        }
        throw new TimeoutException("옷감 가공 설비 화면을 60초 안에 확인하지 못했습니다.");
    }

    private async Task QueueOneClothAsync(CancellationToken ct)
    {
        // Select the material every time. If the game keeps the selection, the same click is harmless;
        // if it resets the selection after queueing, this prevents a wrong recipe from being queued.
        bool clothClicked = await TryClickTemplateAsync("cloth_item_label.jpg", 5, ct, 0.48)
            || await TryClickTemplateAsync("cloth_item_icon.jpg", 5, ct, 0.48);
        if (!clothClicked)
            throw new TimeoutException("가공 설비에서 옷감 항목을 찾지 못했습니다.");

        await ClickTemplateOrTextAsync("process_go.jpg", "가공하러 가기", "가공하러 가기", 8, ct, 0.52);
        await Task.Delay(_settings.ClickSettleMs, ct);

        using var after = _capture.CaptureClient(_hwnd);
        if (await IsMaterialShortageAsync(after, ct))
            return;
    }

    private bool IsQueueFull(Bitmap frame)
    {
        Rectangle slotsRoi = GetProcessingSlotsRoi(frame);
        int iconCount = _matcher.FindAll(
            frame, slotsRoi, "slot_cloth_icon.jpg",
            threshold: 0.60, minScale: 0.45, maxScale: 1.55, step: 0.08, maxMatches: 10).Count;

        // The 7th slot starts at 0%, so this exact slot template is a useful second signal.
        int zeroSlotCount = _matcher.FindAll(
            frame, slotsRoi, "slot_cloth.jpg",
            threshold: 0.58, minScale: 0.45, maxScale: 1.55, step: 0.08, maxMatches: 10).Count;

        // 7번째 슬롯이 실제로 채워졌다는 뜻은 7개의 서로 다른 옷감 아이콘이 보여야 한다는 뜻이다.
        // 6개만 보이는 상태를 가득 참으로 오인하면 재료를 덜 넣고 대기할 수 있으므로 완화 조건은 사용하지 않는다.
        bool full = iconCount >= 7;
        if (full) Emit($"가공 대기열 가득 참 · 옷감 슬롯 감지={iconCount}, 0% 슬롯={zeroSlotCount}");
        return full;
    }

    private async Task<bool> IsQueueCompletedAsync(Bitmap frame, CancellationToken ct)
    {
        Rectangle slotsRoi = GetProcessingSlotsRoi(frame);
        int visual = _matcher.FindAll(
            frame, slotsRoi, "slot_done.jpg",
            threshold: 0.59, minScale: 0.45, maxScale: 1.55, step: 0.08, maxMatches: 10).Count;

        if (visual >= 7)
        {
            Emit("7번 슬롯까지 완료 감지 · 완료 슬롯 7개");
            return true;
        }

        // OCR is the fallback and also protects against completion-ring animation changes.
        int hundred = await _ocr.CountExactAsync(frame, slotsRoi, "100%", ct);
        if (hundred >= 7)
        {
            Emit($"7번 슬롯까지 100% OCR 확인 · 100%={hundred}개");
            return true;
        }
        return false;
    }

    private Rectangle GetProcessingSlotsRoi(Bitmap frame)
    {
        var full = Full(frame);
        MatchResult off = _matcher.Find(frame, full, "receive_all_off.jpg", 0.45, 0.45, 1.60, 0.08);
        MatchResult on = _matcher.Find(frame, full, "receive_all_on.jpg", 0.45, 0.45, 1.60, 0.08);
        MatchResult anchor = on.Score >= off.Score ? on : off;
        if (anchor.Rect.IsEmpty)
            return new Rectangle(0, 0, frame.Width, Math.Max(1, (int)(frame.Height * 0.55)));

        int x = Math.Clamp(anchor.Rect.Right, 0, frame.Width - 1);
        int y = Math.Max(0, anchor.Rect.Top - anchor.Rect.Height / 2);
        int bottom = Math.Min(frame.Height, anchor.Rect.Bottom + anchor.Rect.Height * 4);
        return Rectangle.FromLTRB(x, y, frame.Width, Math.Max(y + 1, bottom));
    }

    private async Task ReceiveAllAsync(CancellationToken ct)
    {
        bool clicked = await TryClickTemplateAsync("receive_all_on.jpg", 4, ct, 0.50);
        if (!clicked)
            await ClickExactTextAsync("모두 받기", "모두 받기", 6, ct);

        await ClickTemplateOrTextAsync("confirm.jpg", "확인", "확인", 10, ct, 0.52);
        Emit("가공품 모두 받기 완료");
    }

    private async Task<bool> IsMaterialShortageAsync(Bitmap frame, CancellationToken ct)
    {
        var image = _matcher.Find(frame, Full(frame), "shortage.jpg", 0.56, 0.45, 1.60, 0.08);
        if (!image.Rect.IsEmpty)
        {
            // A strong toast image is sufficient; OCR is also sampled below when the score is borderline.
            if (image.Score >= 0.68) return true;
            bool text = await _ocr.ContainsAsync(frame, Full(frame), "재료가 부족합니다", ct);
            if (text) return true;
        }

        if ((DateTime.UtcNow - _lastShortageOcrAt).TotalMilliseconds >= 1200)
        {
            _lastShortageOcrAt = DateTime.UtcNow;
            _lastShortageOcrValue = await _ocr.ContainsAsync(frame, Full(frame), "재료가 부족합니다", ct);
        }
        return _lastShortageOcrValue;
    }

    private async Task RunGatheringUntilTargetAsync(CancellationToken ct)
    {
        Stage("양 위치 찾기");
        await OpenCharacterMenuAsync(ct);
        await ClickTemplateOrTextAsync("life_skill.jpg", "생활 스킬", "생활 스킬", 12, ct, 0.50);
        await ClickTemplateOrTextAsync("shearing_skill.jpg", "양털 깎기", "양털 깎기", 12, ct, 0.50);
        await ClickTemplateOrTextAsync("sheep.jpg", "양", "양", 12, ct, 0.52);
        await ClickTemplateOrTextAsync("nearest.jpg", "가까운 위치 찾기", "가까운 위치 찾기", 12, ct, 0.50);

        Stage("양 위치 이동 · 게이지 확인");
        await WaitGaugeMovementAsync(60, ct);

        Stage("황금 양털 경로 설정");
        await OpenBagAsync(ct);
        await EnsureItemTabActiveAsync(ct);
        await ApplyItemSearchAsync("황금 양털", ct);

        // Never click 황금 양털+ by image similarity. Exact OCR text is required here.
        LifeOcrLine golden = await WaitExactTextAsync("황금 양털", 12, ct);
        Click(golden.Bounds);
        await Task.Delay(_settings.ClickSettleMs, ct);

        await ClickTemplateOrTextAsync("get_method.jpg", "구하는 방법", "구하는 방법", 12, ct, 0.50);
        await ClickTemplateOrTextAsync("shearing_get.jpg", "양털 깎기", "양털 깎기", 12, ct, 0.50);

        Stage("무한 채집 시작 확인");
        await WaitGaugeMovementAsync(60, ct);
        _gatherCycles++;
        CountersChanged?.Invoke(_processingBatches, _gatherCycles);
        Emit("무한 양털 채집 시작 확인");

        // Give the game a little time before opening the bag for the first count check.
        await Task.Delay(Math.Min(5000, _settings.WoolCheckIntervalSeconds * 1000), ct);

        while (true)
        {
            ct.ThrowIfCancellationRequested();
            Stage($"양털 수량 확인 · 목표 {_settings.WoolTarget}");
            int? first = await OpenBagAndReadWoolCountAsync(ct);

            if (first.HasValue)
            {
                WoolCountChanged?.Invoke(first.Value);
                Emit($"일반 양털 {first.Value}/{_settings.WoolTarget}");

                if (first.Value >= _settings.WoolTarget)
                {
                    await Task.Delay(700, ct);
                    int? second = await ReadWoolCountFromOpenBagAsync(ct, allowSearchFallback: false);
                    if (second.HasValue)
                    {
                        WoolCountChanged?.Invoke(second.Value);
                        if (second.Value >= _settings.WoolTarget)
                        {
                            Emit($"목표 수량 2회 확인 완료 · {first.Value} → {second.Value}");
                            Stage("목표 달성 · 가공 복귀");
                            await CloseAllPanelsAsync(ct, allowNoX: false);
                            return;
                        }
                        Emit($"목표 수량 2차 확인 불일치 · {first.Value} → {second.Value}");
                    }
                }
            }
            else
            {
                Emit("양털 수량 OCR 실패 · 다음 확인 때 재시도");
            }

            await CloseAllPanelsAsync(ct, allowNoX: true);
            Stage("양털 채집 중");
            await Task.Delay(_settings.WoolCheckIntervalSeconds * 1000, ct);
        }
    }

    private async Task OpenCharacterMenuAsync(CancellationToken ct)
    {
        // Persisted coordinates survive avatar changes. Every coordinate click is verified by the
        // appearance of the Life Skill menu; if verification fails, image recognition is used again.
        if (_settings.CharacterButtonX.HasValue && _settings.CharacterButtonY.HasValue)
        {
            var point = new System.Drawing.Point(_settings.CharacterButtonX.Value, _settings.CharacterButtonY.Value);
            Emit($"캐릭터 아이콘 저장 위치 사용 ({point.X},{point.Y})");
            _input.ClickClientPoint(_hwnd, point);
            await Task.Delay(_settings.ClickSettleMs, ct);
            if (await WaitTemplateFoundAsync("life_skill.jpg", 3, ct, 0.48)) return;

            Emit("저장된 캐릭터 위치 검증 실패 → 이미지 재탐색");
            _settings.CharacterButtonX = null;
            _settings.CharacterButtonY = null;
            _settings.Save(_settingsPath);
            await CloseAllPanelsAsync(ct, allowNoX: true);
        }

        MatchResult match = await WaitTemplateAsync("character.jpg", "캐릭터 아이콘", 15, ct, threshold: 0.47);
        System.Drawing.Point center = Center(match.Rect);
        _input.ClickClientPoint(_hwnd, center);
        await Task.Delay(_settings.ClickSettleMs, ct);
        await WaitTemplateAsync("life_skill.jpg", "생활 스킬 메뉴", 8, ct, threshold: 0.48);

        _settings.CharacterButtonX = center.X;
        _settings.CharacterButtonY = center.Y;
        _settings.Save(_settingsPath);
        Emit($"캐릭터 아이콘 위치 저장 ({center.X},{center.Y})");
    }

    private async Task OpenBagAsync(CancellationToken ct)
        => await ClickTemplateAsync("bag.jpg", "가방", 12, ct, threshold: 0.48);

    private async Task EnsureItemTabActiveAsync(CancellationToken ct)
    {
        using (var frame = _capture.CaptureClient(_hwnd))
        {
            if (Found(frame, "item_on.jpg", 0.50))
            {
                Emit("아이템 탭 활성 상태 확인");
                return;
            }
        }

        await ClickTemplateOrTextAsync("item_off.jpg", "아이템 탭", "아이템", 8, ct, 0.48);
        await WaitTemplateAsync("item_on.jpg", "아이템 탭 활성화", 6, ct, threshold: 0.48);
    }

    private async Task ApplyItemSearchAsync(string query, CancellationToken ct)
    {
        await ClickTemplateAsync("magnifier.jpg", "돋보기", 10, ct, threshold: 0.48);
        MatchResult field = await WaitTemplateAsync("search_field.jpg", "아이템 검색 입력창", 8, ct, threshold: 0.46);
        Click(field.Rect);
        await Task.Delay(250, ct);

        _input.PasteText(query);
        await Task.Delay(150, ct);
        _input.TapScanCode(0x1C); // Enter
        await Task.Delay(350, ct);

        bool applyClicked = await TryClickTemplateAsync("apply.jpg", 6, ct, 0.48);
        if (!applyClicked)
            await ClickExactTextAsync("적용하기", "적용하기", 6, ct);
        Emit($"아이템 검색 적용: {query}");
        await Task.Delay(_settings.ClickSettleMs, ct);
    }

    private async Task<int?> OpenBagAndReadWoolCountAsync(CancellationToken ct)
    {
        await OpenBagAsync(ct);
        await EnsureItemTabActiveAsync(ct);
        await Task.Delay(400, ct);
        return await ReadWoolCountFromOpenBagAsync(ct, allowSearchFallback: true);
    }

    private async Task<int?> ReadWoolCountFromOpenBagAsync(CancellationToken ct, bool allowSearchFallback)
    {
        using var frame = _capture.CaptureClient(_hwnd);
        LifeOcrLine? label = await _ocr.FindExactAsync(frame, Full(frame), "양털", ct);

        if (label is not null)
        {
            int? count = await ReadCountNearLabelAsync(frame, label.Bounds, ct);
            if (count.HasValue) return count;
        }

        // Visual fallback for OCR failing to read the short Korean label.
        MatchResult labelImage = _matcher.Find(frame, Full(frame), "wool_label.jpg", 0.48, 0.45, 1.60, 0.08);
        if (!labelImage.Rect.IsEmpty)
        {
            int? count = await ReadCountNearLabelAsync(frame, labelImage.Rect, ct);
            if (count.HasValue) return count;
        }

        if (!allowSearchFallback) return null;

        Emit("일반 양털이 바로 보이지 않음 → 정확한 이름 '양털'로 검색");
        await ApplyItemSearchAsync("양털", ct);
        LifeOcrLine exact = await WaitExactTextAsync("양털", 8, ct);
        using var searched = _capture.CaptureClient(_hwnd);
        return await ReadCountNearLabelAsync(searched, exact.Bounds, ct);
    }

    private async Task<int?> ReadCountNearLabelAsync(Bitmap frame, Rectangle label, CancellationToken ct)
    {
        int centerX = label.Left + label.Width / 2;
        int left = Math.Max(0, centerX - 115);
        int top = Math.Max(0, label.Top - 190);
        int right = Math.Min(frame.Width, centerX + 115);
        int bottom = Math.Min(frame.Height, label.Top + 10);
        if (right <= left || bottom <= top) return null;

        Rectangle roi = Rectangle.FromLTRB(left, top, right, bottom);
        List<int> values = await _ocr.ReadIntegersAsync(frame, roi, ct);
        // Inventory count is the only 1-4 digit number in the tight item region in the captured UI.
        // Prefer the largest value if OCR duplicates the same number at two scales.
        return values.Where(v => v is >= 0 and <= 9999).DefaultIfEmpty(-1).Max() is int n && n >= 0 ? n : null;
    }

    private async Task WaitGaugeMovementAsync(int timeoutSeconds, CancellationToken ct)
    {
        DateTime deadline = DateTime.UtcNow.AddSeconds(timeoutSeconds);
        int? previous = null;
        int changes = 0;
        int seen = 0;

        while (DateTime.UtcNow < deadline)
        {
            ct.ThrowIfCancellationRequested();
            using var frame = _capture.CaptureClient(_hwnd);
            int? width = FindGreenGaugeFillWidth(frame);
            if (width.HasValue)
            {
                seen++;
                if (previous.HasValue && Math.Abs(width.Value - previous.Value) >= 4)
                {
                    changes++;
                    if (changes >= 2)
                    {
                        Emit($"채집 게이지 움직임 확인 · 변화 {changes}회");
                        return;
                    }
                }
                previous = width;
            }
            else if (seen > 0)
            {
                // A disappearing fill between frames is also a meaningful gauge cycle change.
                changes++;
                previous = null;
                if (changes >= 2)
                {
                    Emit("채집 게이지 반복 변화 확인");
                    return;
                }
            }

            await Task.Delay(350, ct);
        }

        throw new TimeoutException($"{timeoutSeconds}초 안에 채집 게이지 움직임을 확인하지 못했습니다.");
    }

    private static int? FindGreenGaugeFillWidth(Bitmap frame)
    {
        using var bgr = BitmapConverter.ToMat(frame);
        Rectangle rr = new(
            (int)(frame.Width * 0.12),
            (int)(frame.Height * 0.25),
            Math.Max(1, (int)(frame.Width * 0.76)),
            Math.Max(1, (int)(frame.Height * 0.58)));
        rr = Rectangle.Intersect(rr, new Rectangle(System.Drawing.Point.Empty, frame.Size));
        if (rr.Width <= 0 || rr.Height <= 0) return null;

        using var roi = new Mat(bgr, new OpenCvSharp.Rect(rr.X, rr.Y, rr.Width, rr.Height));
        using var hsv = new Mat();
        Cv2.CvtColor(roi, hsv, ColorConversionCodes.BGR2HSV);
        using var mask = new Mat();
        Cv2.InRange(hsv, new Scalar(32, 95, 75), new Scalar(92, 255, 255), mask);
        using var kernel = Cv2.GetStructuringElement(MorphShapes.Rect, new OpenCvSharp.Size(5, 3));
        Cv2.MorphologyEx(mask, mask, MorphTypes.Close, kernel);

        Cv2.FindContours(mask, out OpenCvSharp.Point[][] contours, out _, RetrievalModes.External, ContourApproximationModes.ApproxSimple);
        int bestWidth = 0;
        double bestScore = double.NegativeInfinity;
        foreach (var contour in contours)
        {
            var r = Cv2.BoundingRect(contour);
            if (r.Width < 35 || r.Width > frame.Width * 0.45) continue;
            if (r.Height < 4 || r.Height > 45) continue;
            double aspect = r.Width / (double)Math.Max(1, r.Height);
            if (aspect < 3.0) continue;

            double centerPenalty = Math.Abs((rr.X + r.X + r.Width / 2.0) - frame.Width / 2.0) / Math.Max(1, frame.Width);
            double score = r.Width - centerPenalty * 45.0;
            if (score > bestScore)
            {
                bestScore = score;
                bestWidth = r.Width;
            }
        }
        return bestWidth > 0 ? bestWidth : null;
    }

    private async Task CloseAllPanelsAsync(CancellationToken ct, bool allowNoX)
    {
        int noX = 0;
        int clicks = 0;
        while (clicks < 12)
        {
            ct.ThrowIfCancellationRequested();
            using var frame = _capture.CaptureClient(_hwnd);
            // 사용자가 지정한 닫기 버튼은 우측 상단에 있다. 검색창의 작은 x 같은 다른 UI를
            // 오인하지 않도록 화면 우측 상단 영역에서만 두 종류의 X를 찾는다.
            Rectangle closeRoi = new(
                (int)(frame.Width * 0.52),
                0,
                Math.Max(1, frame.Width - (int)(frame.Width * 0.52)),
                Math.Max(1, (int)(frame.Height * 0.42)));
            MatchResult white = _matcher.Find(frame, closeRoi, "x_white.jpg", 0.54, 0.45, 1.60, 0.08);
            MatchResult gray = _matcher.Find(frame, closeRoi, "x_gray.jpg", 0.50, 0.45, 1.60, 0.08);
            MatchResult best = white.Score >= gray.Score ? white : gray;

            if (best.Rect.IsEmpty)
            {
                noX++;
                if (noX >= 2)
                {
                    if (clicks > 0) Emit($"X 버튼 {clicks}회 클릭 → 모든 창 닫힘 확인");
                    else if (!allowNoX) Emit("X 버튼 없음 · 이미 기본 화면으로 판단");
                    return;
                }
                await Task.Delay(350, ct);
                continue;
            }

            noX = 0;
            Click(best.Rect);
            clicks++;
            await Task.Delay(Math.Max(450, _settings.ClickSettleMs), ct);
        }

        throw new InvalidOperationException("X 버튼을 12회 닫았지만 UI가 계속 열려 있습니다.");
    }

    private bool Found(Bitmap frame, string template, double threshold)
        => !_matcher.Find(frame, Full(frame), template, threshold, 0.40, 1.65, 0.08).Rect.IsEmpty;

    private async Task<MatchResult> WaitTemplateAsync(
        string template,
        string description,
        int timeoutSeconds,
        CancellationToken ct,
        double threshold)
    {
        DateTime deadline = DateTime.UtcNow.AddSeconds(timeoutSeconds);
        MatchResult best = new() { Score = 0, Rect = Rectangle.Empty };
        while (DateTime.UtcNow < deadline)
        {
            ct.ThrowIfCancellationRequested();
            using var frame = _capture.CaptureClient(_hwnd);
            MatchResult hit = _matcher.Find(frame, Full(frame), template, threshold, 0.40, 1.65, 0.08);
            if (hit.Score > best.Score) best = hit;
            if (!hit.Rect.IsEmpty) return hit;
            await Task.Delay(_settings.TemplatePollMs, ct);
        }
        throw new TimeoutException($"{description} 인식 시간초과 · best={best.Score:F3}");
    }

    private async Task<bool> WaitTemplateFoundAsync(string template, int timeoutSeconds, CancellationToken ct, double threshold)
    {
        DateTime deadline = DateTime.UtcNow.AddSeconds(timeoutSeconds);
        while (DateTime.UtcNow < deadline)
        {
            ct.ThrowIfCancellationRequested();
            using var frame = _capture.CaptureClient(_hwnd);
            if (Found(frame, template, threshold)) return true;
            await Task.Delay(_settings.TemplatePollMs, ct);
        }
        return false;
    }

    private async Task ClickTemplateAsync(
        string template,
        string description,
        int timeoutSeconds,
        CancellationToken ct,
        double threshold)
    {
        MatchResult hit = await WaitTemplateAsync(template, description, timeoutSeconds, ct, threshold);
        Click(hit.Rect);
        Emit($"{description} 클릭 · score={hit.Score:F3}");
        await Task.Delay(_settings.ClickSettleMs, ct);
    }

    private async Task<bool> TryClickTemplateAsync(string template, int timeoutSeconds, CancellationToken ct, double threshold)
    {
        DateTime deadline = DateTime.UtcNow.AddSeconds(timeoutSeconds);
        while (DateTime.UtcNow < deadline)
        {
            ct.ThrowIfCancellationRequested();
            using var frame = _capture.CaptureClient(_hwnd);
            MatchResult hit = _matcher.Find(frame, Full(frame), template, threshold, 0.40, 1.65, 0.08);
            if (!hit.Rect.IsEmpty)
            {
                Click(hit.Rect);
                await Task.Delay(_settings.ClickSettleMs, ct);
                return true;
            }
            await Task.Delay(_settings.TemplatePollMs, ct);
        }
        return false;
    }

    private async Task ClickTemplateOrTextAsync(
        string template,
        string description,
        string exactText,
        int timeoutSeconds,
        CancellationToken ct,
        double threshold)
    {
        DateTime deadline = DateTime.UtcNow.AddSeconds(timeoutSeconds);
        while (DateTime.UtcNow < deadline)
        {
            ct.ThrowIfCancellationRequested();
            using var frame = _capture.CaptureClient(_hwnd);
            MatchResult hit = _matcher.Find(frame, Full(frame), template, threshold, 0.40, 1.65, 0.08);
            if (!hit.Rect.IsEmpty)
            {
                Click(hit.Rect);
                Emit($"{description} 클릭 · image={hit.Score:F3}");
                await Task.Delay(_settings.ClickSettleMs, ct);
                return;
            }

            LifeOcrLine? text = await _ocr.FindExactAsync(frame, Full(frame), exactText, ct);
            if (text is not null)
            {
                Click(text.Bounds);
                Emit($"{description} 클릭 · OCR");
                await Task.Delay(_settings.ClickSettleMs, ct);
                return;
            }
            await Task.Delay(_settings.TemplatePollMs, ct);
        }
        throw new TimeoutException($"{description}을(를) 찾지 못했습니다.");
    }

    private async Task ClickExactTextAsync(string exact, string description, int timeoutSeconds, CancellationToken ct)
    {
        LifeOcrLine line = await WaitExactTextAsync(exact, timeoutSeconds, ct);
        Click(line.Bounds);
        Emit($"{description} 클릭 · OCR");
        await Task.Delay(_settings.ClickSettleMs, ct);
    }

    private async Task<LifeOcrLine> WaitExactTextAsync(string exact, int timeoutSeconds, CancellationToken ct)
    {
        DateTime deadline = DateTime.UtcNow.AddSeconds(timeoutSeconds);
        while (DateTime.UtcNow < deadline)
        {
            ct.ThrowIfCancellationRequested();
            using var frame = _capture.CaptureClient(_hwnd);
            LifeOcrLine? line = await _ocr.FindExactAsync(frame, Full(frame), exact, ct);
            if (line is not null) return line;
            await Task.Delay(Math.Max(350, _settings.TemplatePollMs), ct);
        }
        throw new TimeoutException($"OCR 정확 일치 '{exact}'를 찾지 못했습니다.");
    }

    private void Click(Rectangle rect)
        => _input.ClickClientPoint(_hwnd, Center(rect));

    private static System.Drawing.Point Center(Rectangle rect)
        => new(rect.Left + rect.Width / 2, rect.Top + rect.Height / 2);

    private static Rectangle Full(Bitmap frame)
        => new(System.Drawing.Point.Empty, frame.Size);

    private void Stage(string text)
    {
        StageChanged?.Invoke(text);
        Emit("[상태] " + text);
    }

    private void Emit(string text) => Log?.Invoke(text);

    private void SaveDebug(string reason)
    {
        if (!_app.SaveScreenshotOnTimeout) return;
        try
        {
            Directory.CreateDirectory(_debugDir);
            using var frame = _capture.CaptureClient(_hwnd);
            string safe = Regex.Replace(reason, @"[^a-zA-Z0-9가-힣_-]+", "_");
            string path = Path.Combine(_debugDir, $"{DateTime.Now:yyyyMMdd_HHmmss_fff}_{safe}.png");
            frame.Save(path, System.Drawing.Imaging.ImageFormat.Png);
            Emit("디버그 캡처: " + path);
        }
        catch { }
    }

    public void Dispose()
    {
        _input.Dispose();
        _matcher.Dispose();
    }
}
