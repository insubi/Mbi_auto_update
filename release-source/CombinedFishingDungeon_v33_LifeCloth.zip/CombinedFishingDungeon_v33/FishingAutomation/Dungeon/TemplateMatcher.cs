﻿using OpenCvSharp;
using OpenCvSharp.Extensions;

namespace DungeonVisionBot;

internal sealed class TemplateMatcher
{
    private readonly string _baseDir;
    public TemplateMatcher(string baseDir) => _baseDir = baseDir;

    public DetectionResult Find(Bitmap frame, Rectangle roi, string templatePath, double threshold)
        => FindMultiScale(frame, roi, templatePath, threshold, 1.0, 1.0, 0.10);

    public DetectionResult FindMultiScale(
        Bitmap frame,
        Rectangle roi,
        string templatePath,
        double threshold,
        double minScale,
        double maxScale,
        double step)
    {
        string fullPath = Path.IsPathRooted(templatePath)
            ? templatePath
            : Path.Combine(_baseDir, templatePath.Replace('/', Path.DirectorySeparatorChar));
        if (!File.Exists(fullPath)) return DetectionResult.NotFound;

        minScale = Math.Clamp(minScale, 0.20, 3.00);
        maxScale = Math.Clamp(maxScale, minScale, 3.00);
        step = Math.Clamp(step, 0.02, 0.50);

        using var crop = frame.Clone(roi, System.Drawing.Imaging.PixelFormat.Format24bppRgb);
        using var src = BitmapConverter.ToMat(crop);
        using var tplBmp = new Bitmap(fullPath);
        using var tplOriginal = BitmapConverter.ToMat(tplBmp);
        using var srcGray = new Mat();
        using var tplGrayOriginal = new Mat();
        Cv2.CvtColor(src, srcGray, ColorConversionCodes.BGR2GRAY);
        Cv2.CvtColor(tplOriginal, tplGrayOriginal, ColorConversionCodes.BGR2GRAY);

        double bestScore = double.MinValue;
        OpenCvSharp.Point bestLoc = default;
        int bestW = 0;
        int bestH = 0;

        // Include maxScale even when floating point stepping would skip it.
        var scales = new List<double>();
        for (double scale = minScale; scale <= maxScale + 1e-9; scale += step)
            scales.Add(scale);
        if (scales.Count == 0 || Math.Abs(scales[^1] - maxScale) > 1e-6)
            scales.Add(maxScale);

        foreach (double scale in scales)
        {
            int w = Math.Max(8, (int)Math.Round(tplGrayOriginal.Width * scale));
            int h = Math.Max(8, (int)Math.Round(tplGrayOriginal.Height * scale));
            if (w > srcGray.Width || h > srcGray.Height) continue;

            using var tplGray = new Mat();
            if (w == tplGrayOriginal.Width && h == tplGrayOriginal.Height)
                tplGrayOriginal.CopyTo(tplGray);
            else
                Cv2.Resize(tplGrayOriginal, tplGray, new OpenCvSharp.Size(w, h), 0, 0, InterpolationFlags.Area);

            using var result = new Mat();
            Cv2.MatchTemplate(srcGray, tplGray, result, TemplateMatchModes.CCoeffNormed);
            Cv2.MinMaxLoc(result, out _, out double maxVal, out _, out OpenCvSharp.Point maxLoc);

            if (maxVal > bestScore)
            {
                bestScore = maxVal;
                bestLoc = maxLoc;
                bestW = w;
                bestH = h;
            }
        }

        if (bestW <= 0 || bestH <= 0 || bestScore < threshold)
            return DetectionResult.NotFound;

        var bounds = new Rectangle(roi.X + bestLoc.X, roi.Y + bestLoc.Y, bestW, bestH);
        return new DetectionResult(true, bounds, bestScore, null);
    }
}
