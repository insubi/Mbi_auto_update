hook.png      - current fishing-start icon crop from 800x1000 client

gauge.png     - actual gauge bar crop; code converts it to a fill-invariant capsule mask
healthbar.png - exclusion/reference image supplied by user
compass.png   - compass action icon supplied by user

Do not resize these manually. v6 performs OpenCV multi-scale matching where needed.
