어비스 자동화 템플릿 (800x1000 게임 클라이언트 기준)

menu.png                    메뉴
abyss.png                   어비스
hallucination_anchorage.png 허상의 정박지
madness_cave.png            광기의 동굴
scattered_waterway.png      흩어진 물길
enter.png                   입장하기
 treasure_chest.png          보물상자 (감지만 하고 클릭하지 않음)
exit.png                    나가기

동작 순서:
메뉴 클릭 -> 어비스 클릭 -> 프로그램에서 선택한 던전 클릭 -> 입장하기 클릭
-> 보물상자 감지까지 대기 -> 나가기 클릭 -> 무한 반복
F10 즉시 정지
