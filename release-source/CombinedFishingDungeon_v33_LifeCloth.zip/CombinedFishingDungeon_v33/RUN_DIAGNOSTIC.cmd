@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "LOG=%CD%\diagnostic.txt"
(
  echo ==== CombinedFishingDungeon v23 diagnostic ====
  echo Date: %DATE% %TIME%
  echo Folder: %CD%
  echo.
  echo [Windows]
  ver
  echo.
  echo [.NET]
  where dotnet 2^>nul
  if errorlevel 1 (
    echo dotnet: NOT FOUND
  ) else (
    dotnet --info
  )
  echo.
  echo [Files]
  if exist "FishingAutomation\FishingAutomation.csproj" (echo project: OK) else (echo project: MISSING)
  if exist "FishingAutomation\interception.dll" (echo interception.dll: OK) else (echo interception.dll: MISSING)
  if exist "release\FishingAutomation.exe" (echo release exe: OK) else (echo release exe: NOT BUILT)
  if exist "FishingAutomation\dungeon\config\scenario.json" (echo dungeon config: OK) else (echo dungeon config: MISSING)
  if exist "FishingAutomation\abyss\config\scenario.json" (echo abyss config: OK) else (echo abyss config: MISSING)
  echo.
  echo [Build log tail]
  if exist "build.log" (
    powershell -NoProfile -Command "Get-Content -LiteralPath 'build.log' -Tail 80"
  ) else (
    echo build.log: not created yet
  )
) > "%LOG%" 2>&1

type "%LOG%"
echo.
echo Diagnostic saved: %LOG%
echo If START.cmd still fails, send diagnostic.txt and build.log to ChatGPT.
pause
