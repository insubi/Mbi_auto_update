[휴대폰 텔레그램 알림 설정]

1. Telegram에서 @BotFather를 열고 /newbot 으로 봇을 만듭니다.
2. 발급된 Bot Token을 복사합니다.
3. 만든 봇에게 아무 메시지나 1개 보냅니다.
4. Chat ID를 확인합니다. (getUpdates 또는 Chat ID 확인 봇 사용)
5. 이 폴더의 SETUP_PHONE_ALERT.cmd 를 실행합니다.
6. Bot Token과 Chat ID를 입력하면 테스트 메시지가 휴대폰으로 전송됩니다.

기본 감지 조건
- 낚시: 60초 이상 정상 진행 신호 없음 -> 텔레그램 + 게임 화면 스크린샷
- 네트워크 재시도 3회 연속 -> 텔레그램 + 스크린샷
- 던전/어비스 오류 또는 시작 실패 -> 텔레그램 + 스크린샷
- 10분 제한 후 강제 퇴장 절차가 90초 이상 끝나지 않음 -> 텔레그램 + 스크린샷
- 프로그램 UI 생존 신호가 90초 이상 멈춤 -> 외부 MacroWatchdog.exe가 텔레그램 알림
- 프로그램 비정상 종료 -> 외부 MacroWatchdog.exe가 텔레그램 알림

오경보 방지
- F10 정상 정지는 비정상 종료 알림 대상이 아닙니다.
- 프로그램 창을 정상적으로 닫는 경우도 비정상 종료 알림을 보내지 않습니다.
- 어비스 던전 내부 전투는 정상적으로 최대 10분간 진행될 수 있으므로 단순 60초 무동작으로 정지 판정하지 않습니다.

세부 시간 변경
release\notification.json (또는 빌드 전 FishingAutomation\notification.json)
- FishingStallSeconds: 낚시 정체 감지 시간
- WatchdogSeconds: 프로그램/UI 멈춤 감지 시간
- ExitProcedureTimeoutSeconds: 강제 퇴장 완료 대기 시간
- NetworkRetryAlertCount: 네트워크 재시도 반복 알림 횟수
- SendScreenshot: true/false
