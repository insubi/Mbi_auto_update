@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "ROOT=%CD%"
set "PROJ=%ROOT%\FishingAutomation\FishingAutomation.csproj"
set "OUT=%ROOT%\release"
set "LOG=%ROOT%\build.log"
set "WATCHPROJ=%ROOT%\MacroWatchdog\MacroWatchdog.csproj"
set "WATCHOUT=%ROOT%\watchdog_release"

if not exist "%PROJ%" (
  echo ERROR: Project file not found.
  echo Expected: %PROJ%
  pause
  exit /b 2
)

where dotnet >nul 2>nul
if errorlevel 1 (
  echo ERROR: .NET 8 SDK is not installed or not in PATH.
  echo Install .NET 8 SDK, then run this file again.
  echo https://dotnet.microsoft.com/download/dotnet/8.0
  pause
  exit /b 3
)

if exist "%LOG%" del /q "%LOG%" >nul 2>nul

echo [1/3] Checking .NET...
dotnet --version

echo [2/3] Restoring packages...
dotnet restore "%PROJ%" >>"%LOG%" 2>&1
if errorlevel 1 goto :fail

echo [3/4] Publishing Windows x64...
if exist "%OUT%" rmdir /s /q "%OUT%"
dotnet publish "%PROJ%" -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o "%OUT%" >>"%LOG%" 2>&1
if errorlevel 1 goto :fail

echo [4/4] Publishing watchdog...
if exist "%WATCHOUT%" rmdir /s /q "%WATCHOUT%"
dotnet publish "%WATCHPROJ%" -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o "%WATCHOUT%" >>"%LOG%" 2>&1
if errorlevel 1 goto :fail
copy /y "%WATCHOUT%\MacroWatchdog.exe" "%OUT%\MacroWatchdog.exe" >nul

if not exist "%OUT%\FishingAutomation.exe" (
  echo ERROR: Publish completed but EXE was not found.
  goto :fail
)

echo.
echo BUILD OK
exit /b 0

:fail
echo.
echo BUILD FAILED. Open this file and send it to ChatGPT:
echo %LOG%
echo.
type "%LOG%"
pause
exit /b 1
