MABI AUTO 자동 업데이트 사용법
============================

현재 업데이트 저장소:
https://github.com/insubi/Mbi_auto_update

프로그램은 시작할 때 GitHub의 최신 Release를 확인합니다.
새 버전(v30, v31...)이 있으면 오른쪽 '빠른 설정'에서 표시됩니다.

업데이트 순서
1) 매크로를 F10으로 정지합니다.
2) '업데이트 확인' 버튼을 누릅니다.
3) 새 버전 안내에서 '예'를 누릅니다.
4) ZIP 다운로드 후 프로그램이 종료됩니다.
5) tools/ApplyUpdate.ps1가 파일을 교체합니다.
6) 기존 텔레그램 설정/기본 설정/템플릿/Interception DLL은 보존됩니다.
7) release 폴더를 새로 빌드하고 프로그램이 다시 시작됩니다.

중요
- 자동 업데이트는 공개 GitHub Release의 ZIP asset을 사용합니다.
- Release에는 반드시 .zip 파일을 하나 이상 첨부하세요.
- Bot Token이 들어있는 사용자의 notification.json은 GitHub Release에 올리지 마세요.
- 업데이트 적용에는 현재 패키지와 동일하게 .NET 8 SDK가 필요합니다.
