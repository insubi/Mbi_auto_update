@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "LOG=%CD%\diagnostic.txt"
(
  echo ==== MABI AUTO v30 diagnostic ====
  echo Date: %DATE% %TIME%
  echo Folder: %CD%
  echo.
  echo [Windows]
  ver
  echo.
  echo [Runtime package]
  if exist "release\FishingAutomation.exe" (echo FishingAutomation.exe: OK) else (echo FishingAutomation.exe: MISSING)
  if exist "release\MacroWatchdog.exe" (echo MacroWatchdog.exe: OK) else (echo MacroWatchdog.exe: MISSING)
  if exist "START.cmd" (echo START.cmd: OK) else (echo START.cmd: MISSING)
  echo .NET SDK is NOT required for Windows_Lite.
  echo.
  echo [Input / settings]
  if exist "FishingAutomation\interception.dll" (echo interception.dll: OK) else (echo interception.dll: MISSING)
  if exist "FishingAutomation\notification.json" (echo notification.json: OK) else (echo notification.json: MISSING)
  if exist "FishingAutomation\config.json" (echo config.json: OK) else (echo config.json: MISSING)
  echo.
  echo [Dungeon configs]
  if exist "FishingAutomation\dungeon\config\scenario.json" (echo dungeon config: OK) else (echo dungeon config: MISSING)
  if exist "FishingAutomation\abyss\config\scenario.json" (echo abyss config: OK) else (echo abyss config: MISSING)
  echo.
  echo [Update state]
  if exist ".update_pending" (echo update pending: YES) else (echo update pending: NO)
  if exist ".update_rollback" (echo rollback backup: PRESENT) else (echo rollback backup: NONE)
  echo.
  echo [Update log tail]
  if exist "update.log" (
    powershell -NoProfile -Command "Get-Content -LiteralPath 'update.log' -Tail 80"
  ) else (
    echo update.log: not created yet
  )
) > "%LOG%" 2>&1

type "%LOG%"
echo.
echo Diagnostic saved: %LOG%
echo If a problem occurs, send diagnostic.txt and update.log to ChatGPT.
pause
