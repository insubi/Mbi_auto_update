﻿using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;

namespace FishingAutomation;

internal static class NativeMethods
{
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern int GetWindowTextLength(IntPtr hWnd);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);
    [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr hWnd, out RECT lpRect);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
    [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr hWnd, ref POINT lpPoint);
    [DllImport("user32.dll", SetLastError = true)] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr insertAfter, int X, int Y, int cx, int cy, uint flags);
    [DllImport("user32.dll", SetLastError = true)] public static extern bool MoveWindow(IntPtr hWnd, int X, int Y, int nWidth, int nHeight, bool bRepaint);
    [DllImport("user32.dll", SetLastError = true)] public static extern bool GetWindowPlacement(IntPtr hWnd, ref WINDOWPLACEMENT lpwndpl);
    [DllImport("user32.dll", SetLastError = true)] public static extern bool SetWindowPlacement(IntPtr hWnd, ref WINDOWPLACEMENT lpwndpl);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool IsZoomed(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
    [DllImport("user32.dll", SetLastError = true)] public static extern int GetWindowLong(IntPtr hWnd, int nIndex);
    [DllImport("user32.dll", SetLastError = true)] public static extern bool AdjustWindowRectEx(ref RECT lpRect, uint dwStyle, bool bMenu, uint dwExStyle);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);
    [DllImport("user32.dll")] public static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);
    [DllImport("user32.dll")] public static extern bool UnregisterHotKey(IntPtr hWnd, int id);
    [DllImport("user32.dll", SetLastError = true)] public static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

    public const int GWL_STYLE = -16;
    public const int GWL_EXSTYLE = -20;
    public const uint SWP_NOZORDER = 0x0004;
    public const uint SWP_NOACTIVATE = 0x0010;
    public const uint SWP_FRAMECHANGED = 0x0020;
    public const int SW_SHOWNORMAL = 1;
    public const int SW_RESTORE = 9;
    public const uint KEYEVENTF_KEYUP = 0x0002;
    public const uint KEYEVENTF_SCANCODE = 0x0008;
    public const uint INPUT_KEYBOARD = 1;
    public const uint MOD_NOREPEAT = 0x4000;
    public const int WM_HOTKEY = 0x0312;
    public const uint VK_F8 = 0x77;
    public const uint VK_F9 = 0x78;
    public const uint VK_F10 = 0x79;

    [StructLayout(LayoutKind.Sequential)]
    public struct RECT { public int Left, Top, Right, Bottom; }
    [StructLayout(LayoutKind.Sequential)]
    public struct POINT { public int X, Y; }

    [StructLayout(LayoutKind.Sequential)]
    public struct WINDOWPLACEMENT
    {
        public int length;
        public int flags;
        public int showCmd;
        public POINT ptMinPosition;
        public POINT ptMaxPosition;
        public RECT rcNormalPosition;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct INPUT
    {
        public uint type;
        public InputUnion U;
    }

    [StructLayout(LayoutKind.Explicit)]
    public struct InputUnion
    {
        [FieldOffset(0)] public KEYBDINPUT ki;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct KEYBDINPUT
    {
        public ushort wVk;
        public ushort wScan;
        public uint dwFlags;
        public uint time;
        public UIntPtr dwExtraInfo;
    }
}

public sealed class GameWindow
{
    public IntPtr Handle { get; }
    public int ClientWidth { get; }
    public int ClientHeight { get; }
    public Point ClientScreenOrigin { get; }

    public GameWindow(IntPtr handle, int width, int height, Point origin)
    {
        Handle = handle;
        ClientWidth = width;
        ClientHeight = height;
        ClientScreenOrigin = origin;
    }
}

public static class WindowLocator
{
    public static GameWindow? FindAndPrepare(AutomationConfig cfg, AppLog log)
    {
        IntPtr hwnd = IntPtr.Zero;
        long bestArea = -1;

        NativeMethods.EnumWindows((h, _) =>
        {
            if (!NativeMethods.IsWindowVisible(h) || NativeMethods.IsIconic(h)) return true;
            int len = NativeMethods.GetWindowTextLength(h);
            if (len <= 0) return true;
            var sb = new StringBuilder(len + 1);
            NativeMethods.GetWindowText(h, sb, sb.Capacity);
            string title = sb.ToString();
            if (!title.Contains("마비노기 모바일", StringComparison.OrdinalIgnoreCase)) return true;
            if (!NativeMethods.GetClientRect(h, out var rr)) return true;
            long area = Math.Max(0, rr.Right - rr.Left) * (long)Math.Max(0, rr.Bottom - rr.Top);
            if (area > bestArea)
            {
                bestArea = area;
                hwnd = h;
            }
            return true;
        }, IntPtr.Zero);

        if (hwnd == IntPtr.Zero && !string.IsNullOrWhiteSpace(cfg.GameProcessName))
        {
            foreach (var p in Process.GetProcessesByName(cfg.GameProcessName))
            {
                try
                {
                    if (p.MainWindowHandle != IntPtr.Zero && NativeMethods.IsWindowVisible(p.MainWindowHandle))
                    {
                        hwnd = p.MainWindowHandle;
                        break;
                    }
                }
                catch { }
            }
        }

        if (hwnd == IntPtr.Zero) return null;

        // v59: macro start always restores the canonical capture geometry.
        // Existing user config may have AutoPlaceWindow=false from an older install.
        TryPlaceWindow(hwnd, cfg, log);

        if (!NativeMethods.GetClientRect(hwnd, out var r)) return null;
        int w = r.Right - r.Left;
        int hgt = r.Bottom - r.Top;
        var pt = new NativeMethods.POINT { X = 0, Y = 0 };
        if (!NativeMethods.ClientToScreen(hwnd, ref pt)) return null;

        if (Math.Abs(w - cfg.ClientWidth) > 2 || Math.Abs(hgt - cfg.ClientHeight) > 2)
        {
            log.Write($"게임 클라이언트 크기 불일치: 현재 {w}x{hgt}, 필요 {cfg.ClientWidth}x{cfg.ClientHeight}");
            return null;
        }

        return new GameWindow(hwnd, w, hgt, new Point(pt.X, pt.Y));
    }

    public static void ActivateForInput(GameWindow window)
    {
        try
        {
            if (NativeMethods.IsIconic(window.Handle))
                NativeMethods.ShowWindow(window.Handle, NativeMethods.SW_RESTORE);
            NativeMethods.BringWindowToTop(window.Handle);
            NativeMethods.SetForegroundWindow(window.Handle);
            Thread.Sleep(45);
        }
        catch { }
    }

    private static void TryPlaceWindow(IntPtr hwnd, AutomationConfig cfg, AppLog log)
    {
        try
        {
            if (NativeMethods.IsIconic(hwnd) || NativeMethods.IsZoomed(hwnd))
            {
                NativeMethods.ShowWindow(hwnd, NativeMethods.SW_RESTORE);
                Thread.Sleep(220);
            }

            var primary = Screen.PrimaryScreen ?? Screen.FromHandle(hwnd);
            Rectangle work = primary.WorkingArea;

            for (int attempt = 0; attempt < 5; attempt++)
            {
                if (!NativeMethods.GetWindowRect(hwnd, out var wr) ||
                    !NativeMethods.GetClientRect(hwnd, out var cr))
                    return;

                int clientW = cr.Right - cr.Left;
                int clientH = cr.Bottom - cr.Top;
                int outerW = wr.Right - wr.Left;
                int outerH = wr.Bottom - wr.Top;

                if (Math.Abs(clientW - cfg.ClientWidth) <= 1 &&
                    Math.Abs(clientH - cfg.ClientHeight) <= 1)
                {
                    int x = work.Right - outerW;
                    if (!NativeMethods.SetWindowPos(hwnd, IntPtr.Zero, x, work.Top, outerW, outerH,
                        NativeMethods.SWP_NOZORDER | NativeMethods.SWP_NOACTIVATE | NativeMethods.SWP_FRAMECHANGED))
                    {
                        int error = Marshal.GetLastWin32Error();
                        log.Write($"게임 창 위치 변경 실패: Win32 {error} (관리자 권한 확인)");
                        return;
                    }

                    log.Write($"게임 창 맞춤 완료: {clientW}x{clientH} · 주 모니터 우상단");
                    return;
                }

                int targetOuterW = Math.Max(1, outerW + (cfg.ClientWidth - clientW));
                int targetOuterH = Math.Max(1, outerH + (cfg.ClientHeight - clientH));
                int targetX = work.Right - targetOuterW;

                if (!NativeMethods.SetWindowPos(hwnd, IntPtr.Zero, targetX, work.Top,
                    targetOuterW, targetOuterH,
                    NativeMethods.SWP_NOZORDER | NativeMethods.SWP_NOACTIVATE | NativeMethods.SWP_FRAMECHANGED))
                {
                    int error = Marshal.GetLastWin32Error();
                    log.Write($"게임 창 크기 변경 실패: Win32 {error} (관리자 권한 확인)");
                    return;
                }

                Thread.Sleep(attempt == 0 ? 240 : 140);
            }

            if (NativeMethods.GetClientRect(hwnd, out var finalRect))
            {
                int finalW = finalRect.Right - finalRect.Left;
                int finalH = finalRect.Bottom - finalRect.Top;
                log.Write($"게임 창 맞춤 결과: {finalW}x{finalH} (목표 {cfg.ClientWidth}x{cfg.ClientHeight})");
            }
        }
        catch (Exception ex)
        {
            log.Write("게임 창 자동 맞춤 실패: " + ex.Message);
        }
    }

}
